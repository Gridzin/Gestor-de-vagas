# Instruções para Configuração das Credenciais do Google Sheets

Para que o site possa enviar dados diretamente para a planilha do Google, é necessário configurar as credenciais de acesso à API do Google Sheets. Siga os passos abaixo:

## 1. Criar um Projeto no Google Cloud Platform

1. Acesse o [Console do Google Cloud](https://console.cloud.google.com/)
2. Crie um novo projeto ou selecione um existente
3. Ative a API do Google Sheets e a API do Google Drive para o projeto

## 2. Criar Credenciais de Conta de Serviço

1. No console do Google Cloud, vá para "APIs e Serviços" > "Credenciais"
2. Clique em "Criar Credenciais" e selecione "Conta de serviço"
3. Preencha os detalhes da conta de serviço e conceda o papel de "Editor" 
4. Crie uma chave para a conta de serviço no formato JSON
5. Faça o download do arquivo JSON de credenciais

## 3. Compartilhar a Planilha com a Conta de Serviço

1. Abra sua planilha do Google Sheets
2. Clique no botão "Compartilhar" no canto superior direito
3. Adicione o email da conta de serviço (encontrado no arquivo JSON de credenciais)
4. Conceda permissão de "Editor" à conta de serviço

## 4. Configurar o Aplicativo

1. Renomeie o arquivo JSON de credenciais para `credentials.json`
2. Coloque o arquivo `credentials.json` na pasta raiz do projeto
3. Configure a variável de ambiente `SPREADSHEET_ID` com o ID da sua planilha (opcional)
   - O ID da planilha é a parte da URL entre `/d/` e `/edit`
   - Exemplo: `https://docs.google.com/spreadsheets/d/1AbCdEfGhIjKlMnOpQrStUvWxYz/edit` -> ID: `1AbCdEfGhIjKlMnOpQrStUvWxYz`

## Observações

- Se as credenciais não forem configuradas, o aplicativo salvará os dados localmente para sincronização posterior
- Os dados salvos localmente estarão na pasta `data/` do projeto
- Para maior segurança em ambiente de produção, considere usar variáveis de ambiente para armazenar as credenciais
