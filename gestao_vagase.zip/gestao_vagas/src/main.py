import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))  # DON'T CHANGE THIS !!!

from flask import Flask, request, jsonify, render_template, send_from_directory
import json
import gspread
from oauth2client.service_account import ServiceAccountCredentials
from datetime import datetime

app = Flask(__name__)

# Configuração para servir arquivos estáticos
@app.route('/')
def index():
    return send_from_directory('static', 'index.html')

# Rota para processar o envio do formulário
@app.route('/submit', methods=['POST'])
def submit():
    try:
        # Obter dados do formulário
        titulo_vaga = request.form.get('titulo_vaga')
        link_vaga = request.form.get('link_vaga')
        origem_vaga = request.form.get('origem_vaga')
        if origem_vaga == 'Outro':
            origem_vaga = request.form.get('outro_origem')
        data_inscricao = request.form.get('data_inscricao')
        fase_processo = request.form.get('fase_processo')
        acao_necessaria = request.form.get('acao_necessaria')
        qual_acao = request.form.get('qual_acao') if acao_necessaria == 'sim' else ''
        prazo_acao = request.form.get('prazo_acao') if acao_necessaria == 'sim' else ''
        status = request.form.get('status')
        feedback = request.form.get('feedback')
        
        # Verificar se todos os campos obrigatórios foram preenchidos
        if not all([titulo_vaga, link_vaga, origem_vaga, data_inscricao, fase_processo, status]):
            return jsonify({'success': False, 'message': 'Por favor, preencha todos os campos obrigatórios.'})
        
        # Verificar se os campos condicionais foram preenchidos quando necessário
        if acao_necessaria == 'sim' and not all([qual_acao, prazo_acao]):
            return jsonify({'success': False, 'message': 'Por favor, preencha os detalhes da ação necessária.'})
        
        # Preparar dados para envio à planilha
        row_data = [
            titulo_vaga,
            link_vaga,
            origem_vaga,
            data_inscricao,
            fase_processo,
            'Sim' if acao_necessaria == 'sim' else 'Não',
            qual_acao,
            prazo_acao,
            status,
            feedback
        ]
        
        # Tentar enviar para a planilha do Google
        try:
            # Verificar se as credenciais existem
            if not os.path.exists('credentials.json'):
                # Se não existirem, salvar mensagem para processamento posterior
                save_pending_submission(row_data)
                return jsonify({
                    'success': True, 
                    'message': 'Dados salvos localmente. A integração com o Google Sheets será configurada pelo administrador.'
                })
            
            # Se as credenciais existirem, enviar diretamente para o Google Sheets
            result = send_to_google_sheet(row_data)
            if result:
                return jsonify({'success': True, 'message': 'Dados enviados com sucesso para a planilha!'})
            else:
                save_pending_submission(row_data)
                return jsonify({
                    'success': True, 
                    'message': 'Dados salvos localmente devido a um problema de conexão. Serão sincronizados posteriormente.'
                })
                
        except Exception as e:
            # Em caso de erro, salvar localmente
            save_pending_submission(row_data)
            return jsonify({
                'success': True, 
                'message': f'Dados salvos localmente. Erro ao conectar com Google Sheets: {str(e)}'
            })
        
    except Exception as e:
        return jsonify({'success': False, 'message': f'Erro ao processar o formulário: {str(e)}'})

def send_to_google_sheet(row_data):
    """Envia os dados para a planilha do Google"""
    try:
        # Configurar credenciais
        scope = ['https://spreadsheets.google.com/feeds', 'https://www.googleapis.com/auth/drive']
        creds = ServiceAccountCredentials.from_json_keyfile_name('credentials.json', scope)
        client = gspread.authorize(creds)
        
        # Abrir a planilha pelo ID ou título
        # Nota: Isso precisará ser configurado com o ID/título correto da planilha
        spreadsheet_id = os.getenv('SPREADSHEET_ID', '')
        if not spreadsheet_id:
            # Se não houver ID configurado, tentar abrir pelo título
            sheet = client.open("Gestão de Vagas - Modelo2025.1")
        else:
            sheet = client.open_by_key(spreadsheet_id)
        
        # Selecionar a aba "Vagas"
        worksheet = sheet.worksheet("Vagas")
        
        # Adicionar nova linha
        worksheet.append_row(row_data)
        return True
    except Exception as e:
        print(f"Erro ao enviar para Google Sheets: {str(e)}")
        return False

def save_pending_submission(row_data):
    """Salva os dados localmente para sincronização posterior"""
    try:
        # Criar diretório de dados se não existir
        data_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data')
        if not os.path.exists(data_dir):
            os.makedirs(data_dir)
        
        # Nome do arquivo baseado na data/hora
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = os.path.join(data_dir, f"submission_{timestamp}.json")
        
        # Salvar dados como JSON
        with open(filename, 'w') as f:
            json.dump({
                'timestamp': timestamp,
                'data': row_data
            }, f)
        
        return True
    except Exception as e:
        print(f"Erro ao salvar submissão pendente: {str(e)}")
        return False

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
