// Funções para manipulação do formulário
document.addEventListener('DOMContentLoaded', function() {
  // Referências aos elementos do formulário
  const form = document.getElementById('vaga-form');
  const acaoNecessariaRadios = document.querySelectorAll('input[name="acao_necessaria"]');
  const camposCondicionais = document.querySelectorAll('.conditional-field');
  const alertSuccess = document.getElementById('alert-success');
  const alertError = document.getElementById('alert-error');
  const loader = document.getElementById('loader');
  
  // Mostrar/ocultar campos condicionais com base na seleção de "Ação necessária"
  acaoNecessariaRadios.forEach(radio => {
    radio.addEventListener('change', function() {
      const isAcaoNecessaria = this.value === 'sim';
      
      camposCondicionais.forEach(campo => {
        if (isAcaoNecessaria) {
          campo.style.display = 'block';
          // Tornar os campos obrigatórios
          const inputs = campo.querySelectorAll('input, textarea');
          inputs.forEach(input => input.required = true);
        } else {
          campo.style.display = 'none';
          // Remover obrigatoriedade dos campos
          const inputs = campo.querySelectorAll('input, textarea');
          inputs.forEach(input => {
            input.required = false;
            input.value = ''; // Limpar valores
          });
        }
      });
    });
  });
  
  // Mostrar campo "Outro" quando selecionado na origem da vaga
  const origemVagaSelect = document.getElementById('origem_vaga');
  const outroOrigemField = document.getElementById('outro_origem_field');
  
  if (origemVagaSelect && outroOrigemField) {
    origemVagaSelect.addEventListener('change', function() {
      if (this.value === 'Outro') {
        outroOrigemField.style.display = 'block';
        document.getElementById('outro_origem').required = true;
      } else {
        outroOrigemField.style.display = 'none';
        document.getElementById('outro_origem').required = false;
        document.getElementById('outro_origem').value = '';
      }
    });
  }
  
  // Validação do formulário antes do envio
  if (form) {
    form.addEventListener('submit', function(event) {
      event.preventDefault();
      
      // Validar URL
      const linkVaga = document.getElementById('link_vaga');
      if (linkVaga && linkVaga.value && !isValidUrl(linkVaga.value)) {
        showError('Por favor, insira um link válido para a vaga.');
        linkVaga.focus();
        return;
      }
      
      // Mostrar loader
      loader.style.display = 'block';
      
      // Enviar dados para o servidor
      const formData = new FormData(form);
      
      fetch('/submit', {
        method: 'POST',
        body: formData
      })
      .then(response => response.json())
      .then(data => {
        loader.style.display = 'none';
        
        if (data.success) {
          showSuccess(data.message || 'Dados enviados com sucesso!');
          form.reset();
          // Resetar campos condicionais
          camposCondicionais.forEach(campo => {
            campo.style.display = 'none';
          });
          // Resetar campo "Outro origem"
          if (outroOrigemField) {
            outroOrigemField.style.display = 'none';
          }
        } else {
          showError(data.message || 'Ocorreu um erro ao enviar os dados.');
        }
      })
      .catch(error => {
        loader.style.display = 'none';
        showError('Ocorreu um erro ao enviar os dados. Por favor, tente novamente.');
        console.error('Erro:', error);
      });
    });
  }
  
  // Funções auxiliares
  function isValidUrl(url) {
    try {
      new URL(url);
      return true;
    } catch (e) {
      return false;
    }
  }
  
  function showSuccess(message) {
    alertSuccess.textContent = message;
    alertSuccess.style.display = 'block';
    alertError.style.display = 'none';
    
    // Scroll para o topo para mostrar a mensagem
    window.scrollTo({ top: 0, behavior: 'smooth' });
    
    // Esconder a mensagem após 5 segundos
    setTimeout(() => {
      alertSuccess.style.display = 'none';
    }, 5000);
  }
  
  function showError(message) {
    alertError.textContent = message;
    alertError.style.display = 'block';
    alertSuccess.style.display = 'none';
    
    // Scroll para o topo para mostrar a mensagem
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
});
